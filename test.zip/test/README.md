# Harbor Credit Union: Analyst Edition

A harder version of the Harbor lab. The same pretend bank, but the browser-only shortcuts are gone: every
mission is built for a real security tool, and the score is a budget you spend on hints.

- **Open:** http://127.0.0.1:5201 (set `HARBOR_ADV_PORT` to change it)
- **Theme:** navy and gold bank
- **Scoring:** points, hint penalties, optional first blood
- **Level:** intermediate, about 3 hours
- **Tools:** ffuf or gobuster, hydra, Burp Suite, jwt_tool or hashcat, curl

```bash
cd test
docker compose up -d --build
```

The beginner lab (`../raw labs/cyberrangelabs-main/harbor-lab`, port 5101) is unchanged. This lab is the
next step after it.

## Missions

| # | Mission | You will learn about | Suggested tool | Base |
|---|---------|----------------------|----------------|------|
| 1 | The Front Desk | Hidden pages and default passwords | ffuf / gobuster / Burp Intruder | 100 |
| 2 | Who Works Here? | Username enumeration and weak passwords | ffuf / hydra / Burp Intruder | 150 |
| 3 | Lucky Number | Predictable session IDs | ffuf / Burp Intruder | 200 |
| 4 | Remember Me? | Forgeable JSON Web Tokens | jwt_tool / hashcat / Burp JWT Editor | 250 |
| 5 | Forgot My Password | Brute-forceable reset tokens | ffuf / Burp Intruder | 300 |

Each mission has a story, a goal, three hints, and a short "what you learned" lesson once it is solved.
The Toolbox page has downloadable wordlists and tested command templates.

## Scoring: points with a hint budget

- Each mission has a **base value**: 100 / 150 / 200 / 250 / 300. Total base: **1000**.
- **Hint 1 is free.**
- **Hints 2 and 3 each reduce the solve by 15% of the mission's base.**
- A solve never drops below **70% of its base**, even if every hint is opened.
- A wrong flag costs **nothing**. A repeat submission pays **nothing**.
- Missions unlock one after another.
- Ranks: Visitor (0), Trainee (100), Teller (250), Analyst (450), Manager (700), Director (1000).

With every hint on every mission the maximum is **702 points**, which still lands just above Manager.

### First blood (optional)

Start the lab with `FIRST_BLOOD=1` to give the first solver of each mission a **+50 point bonus**:

```bash
FIRST_BLOOD=1 docker compose up -d
```

Maximum score with first blood is **1250** and the top rank is Legend. Off by default, so late starters
are not punished.

## Wordlists and Burp Suite

The `/toolbox` page links to six wordlists served from `/static/wordlists/`:

- `paths.txt` — common `/bank/` paths
- `usernames.txt` — first names, roles and decoys
- `passwords.txt` — common passwords
- `jwt-secrets.txt` — common JWT signing secrets
- `sessions.txt` — `10000` to `10099`
- `tokens.txt` — `1000` to `1999`

It also has command templates for ffuf, hydra, jwt_tool and hashcat, plus a Burp Suite workflow
(Proxy history, Repeater, Intruder, JWT Editor). The commands are starting points, not answers.

## Accounts

The pretend bank has its own made-up people (`riley`, `jordan`, `sam`, ...). The practice login for
missions 3 and 4 is `riley` / `harbor123`, shown on the mission cards. Nothing here is shared with the
other labs.

## Flags and the answer key

Flags look like `HARBOR{front-desk-1a2b3c4d}` and are new on every start. `verify/verify.py` solves every
mission with the same techniques a player would use (including a JWT forge and a 1000-value reset-token
loop) and checks the scoring rules. It is the **answer key**, it is not copied into the image, and running
it changes the lab's state, so restart the lab afterwards.

```bash
python3 verify/verify.py http://127.0.0.1:5201
```

## Safety

The bank is deliberately weak. Keep it on loopback (`127.0.0.1`) or an isolated lab network. Never put it
on the internet. The scoring endpoints follow `../raw labs/cyberrangelabs-main/LAB_CONTRACT.md`; the extra
fields (`base_points`, `hint_costs`, `first_blood`, `bonus`, `max_score`) are additive.
