"""Harbor Credit Union: Analyst Edition.

Five missions, each built around a real security tool. Hints 2 and 3 reduce the
points a solve is worth; hint 1 is always free. Wrong flags never subtract.
"""

MISSIONS = [
    {
        'slug': 'front_desk',
        'title': 'The Front Desk',
        'topic': 'Hidden pages and default passwords',
        'points': 100,
        'tool': 'ffuf / gobuster / Burp Intruder',
        'difficulty': 'Warm-up',
        'story': "Harbor's old staff portal used to be linked in the menu. After a redesign the link disappeared, "
                 "but the page did not. The vendor who built it also left the factory login in place. Attackers do "
                 "not wait for a link: they guess paths.",
        'goal': 'Find the hidden staff portal under /bank/, sign in with the vendor factory account, and read the setup note.',
        'start_url': '/bank',
        'start_label': 'Open the bank website',
        'practice': '',
        'hints': [
            'The portal is still on the server, just not linked. Use a content-discovery tool such as ffuf or '
            'gobuster with a path wordlist. The Toolbox page has paths.txt and a ready command.',
            'Fuzz /bank/FUZZ. A few pages return 200; the staff portal is the one with a login form. Most other paths return 404.',
            'The path is /bank/back-office. The vendor never changed the factory login: admin / admin.',
        ],
        'lesson': {
            'what': "A page that is not linked is not hidden. Attackers enumerate common paths, and the vendor's "
                    "factory login was never changed, so anyone who finds the page gets in.",
            'fix': [
                'Change every default password during setup.',
                'Delete or disable default accounts you do not need.',
                'Do not rely on an unlinked URL as a security control; require authentication and authorisation.',
            ],
        },
    },
    {
        'slug': 'who_works_here',
        'title': 'Who Works Here?',
        'topic': 'Username enumeration and weak passwords',
        'points': 150,
        'tool': 'ffuf / hydra / Burp Intruder',
        'difficulty': 'Easy',
        'story': 'The member login tells you whether a username exists before it checks the password. That is a gift '
                 'to an attacker. The team page gives you a list of first names; a wordlist gives you the rest. One '
                 'employee picked a password that is on every common-password list.',
        'goal': 'Enumerate valid usernames, find the account with a weak password, sign in, and read the message.',
        'start_url': '/bank/login',
        'start_label': 'Open the member login',
        'practice': '',
        'hints': [
            'The API endpoint /api/auth/login returns different JSON for an unknown user and a wrong password. '
            'Use ffuf or Burp Intruder with usernames.txt to find the real accounts.',
            'Now brute-force the passwords for the real usernames. hydra or ffuf can do it with passwords.txt. '
            'Watch for result: success.',
            'The account is jordan and the password is welcome1. Log in and open My account.',
        ],
        'lesson': {
            'what': 'The login API gave different answers for "no such user" and "wrong password", so an attacker '
                    'can find out who has an account. With no limit on guesses, a weak password falls in seconds.',
            'fix': [
                'Return one generic message for every failed login.',
                'Rate-limit or lock the account after a few wrong guesses.',
                'Refuse common passwords and require longer ones.',
            ],
        },
    },
    {
        'slug': 'lucky_number',
        'title': 'Lucky Number',
        'topic': 'Predictable session IDs',
        'points': 200,
        'tool': 'ffuf / Burp Intruder',
        'difficulty': 'Medium',
        'story': "Harbor's session cookie is not random. It is a counter that goes up by one for every login. The "
                 "branch manager logged in this morning, so her session is in the same small range as yours.",
        'goal': "Log in with the practice account, inspect hcu_session, then find the branch manager's session and read her messages.",
        'start_url': '/bank/login',
        'start_label': 'Open the member login',
        'practice': 'riley / harbor123',
        'hints': [
            'Log in as riley / harbor123 and look at the hcu_session cookie in Burp or DevTools. It is a five-digit '
            'number, not a random string.',
            'The seeded sessions are 10000-10099. Use ffuf with sessions.txt and the Cookie header, or Burp Intruder '
            'on the cookie.',
            'The branch manager is session 10003. Request /bank/account with hcu_session=10003.',
        ],
        'lesson': {
            'what': "The session ID was just a counter (10005, 10006, ...). Anyone can guess other people's numbers "
                    "and become them. This is called session hijacking.",
            'fix': [
                'Use long random session IDs that cannot be guessed.',
                'Mark session cookies HttpOnly, Secure and SameSite.',
                'Start a fresh session every time someone logs in.',
            ],
        },
    },
    {
        'slug': 'remember_me',
        'title': 'Remember Me?',
        'topic': 'Forgeable JSON Web Tokens',
        'points': 250,
        'tool': 'jwt_tool / hashcat / Burp JWT Editor',
        'difficulty': 'Medium+',
        'story': '"Remember me" now uses a signed token (a JWT) instead of Base64. That sounds better, but the signing '
                 'secret is a word you have seen before. If you can crack the secret, you can mint a token for anyone.',
        'goal': "Log in with Remember me ticked, crack the JWT secret, forge a token with sub=ceo, and open the CEO's account.",
        'start_url': '/bank/login',
        'start_label': 'Open the member login',
        'practice': 'riley / harbor123',
        'hints': [
            'The hcu_remember cookie is a JWT: three Base64URL parts separated by dots. Decode the header and payload. '
            'The header says HS256.',
            'Crack the secret with jwt_tool -C -d jwt-secrets.txt or hashcat -m 16500. Then sign a new token with sub=ceo.',
            'The secret is harbor2026. Forge {"sub":"ceo"} with HS256 and send it as the hcu_remember cookie.',
        ],
        'lesson': {
            'what': 'A JWT is only as strong as its signing secret. A weak, guessable secret lets an attacker sign a '
                    'token for any user, and the server will believe it.',
            'fix': [
                'Use a long random signing secret and keep it out of source code.',
                'Pin the accepted algorithm (here HS256) and reject alg:none.',
                'Expire tokens, rotate secrets, and revoke sessions on logout.',
            ],
        },
    },
    {
        'slug': 'pet_name',
        'title': 'Forgot My Password',
        'topic': 'Brute-forceable reset tokens',
        'points': 300,
        'tool': 'ffuf / Burp Intruder',
        'difficulty': 'Hard',
        'story': 'Harbor replaced security questions with a four-digit reset code sent by email. The code is short, the '
                 'form has no rate limit, and the site tells you when a code is right.',
        'goal': 'Request a reset for sam, brute-force the four-digit code, set a new password, and log in as Sam.',
        'start_url': '/bank/forgot',
        'start_label': 'Open password reset',
        'practice': '',
        'hints': [
            'The reset code is four digits, so there are only 1000 possibilities. The verify form accepts POST '
            'requests and has no lockout.',
            "Use ffuf or Burp Intruder against /bank/forgot/verify with username=sam and token=FUZZ. tokens.txt has "
            "1000-1999. Match the page that says 'Choose a new password'.",
            'Once ffuf finds the code, submit it in your browser, choose a new password, then log in as sam.',
        ],
        'lesson': {
            'what': 'A four-digit reset code has only 1000 possible values. With no rate limit, an attacker can try '
                    'them all in seconds and take the account.',
            'fix': [
                'Use a long random reset token, not a short numeric code.',
                'Expire tokens quickly and allow each token to be used once.',
                'Rate-limit reset attempts and alert on repeated failures.',
            ],
        },
    },
]

RANKS = [
    (0, 'Visitor'),
    (100, 'Trainee'),
    (250, 'Teller'),
    (450, 'Analyst'),
    (700, 'Manager'),
    (1000, 'Director'),
    (1250, 'Legend'),
]
