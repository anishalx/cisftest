/* Harbor Credit Union: Analyst Edition. Mission Control with point costs and tool hints. */
(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const esc = (v) => String(v === undefined || v === null ? '' : v)
    .replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const NICK_KEY = 'cyberrange:harbor-adv:nick';
  const ADJ = ['Brave', 'Curious', 'Swift', 'Clever', 'Calm', 'Lucky', 'Sunny', 'Bold', 'Gentle', 'Quick'];
  const ANI = ['Otter', 'Falcon', 'Panda', 'Fox', 'Heron', 'Lynx', 'Orca', 'Gecko', 'Badger', 'Seal'];

  let nick = localStorage.getItem(NICK_KEY) || '';
  let missions = [];
  let openSlug = null;
  let lastRank = null;
  const notes = {}; // mission slug -> { kind, text } shown inside the card

  async function api(method, path, body) {
    const res = await fetch(path, {
      method, headers: { 'Content-Type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    let data = null;
    try { data = await res.json(); } catch (_) { /* not JSON */ }
    return { ok: res.ok, status: res.status, data: data || {} };
  }

  const suggest = () => `${ADJ[Math.floor(Math.random() * ADJ.length)]}-${ANI[Math.floor(Math.random() * ANI.length)]}-${10 + Math.floor(Math.random() * 90)}`;

  function toast(text) {
    const el = $('toast');
    el.textContent = text;
    el.style.display = 'block';
    setTimeout(() => { el.style.display = 'none'; }, 5000);
  }

  function showName() {
    $('name-card').style.display = '';
    $('main').style.display = 'none';
    $('nick-input').value = nick || suggest();
  }

  function showMain() {
    $('name-card').style.display = 'none';
    $('main').style.display = '';
    $('nick-show').textContent = nick;
  }

  function renderRank(p) {
    $('rank-title').textContent = p.rank_title || 'Visitor';
    const max = p.max_score || 1000;
    const pct = Math.min(100, Math.round(((p.xp || 0) / max) * 100));
    $('xp-fill').style.width = pct + '%';
    $('xp-text').textContent = p.next_rank
      ? `${p.xp} points. ${p.xp_to_next_rank} more to become ${p.next_rank}.`
      : `${p.xp} points. You reached the top rank!`;
    if (lastRank && lastRank !== p.rank_title) toast(`Rank up! You are now ${p.rank_title}.`);
    lastRank = p.rank_title;
  }

  function hintsHtml(m) {
    let html = '';
    for (let i = 0; i < m.hints_total; i++) {
      if (i < m.hints.length) {
        html += `<div class="hint"><strong>Hint ${i + 1}:</strong> ${esc(m.hints[i])}</div>`;
      } else if (i === m.hints.length && !m.solved) {
        const cost = (m.hint_costs && m.hint_costs[i]) || 0;
        const label = cost
          ? `Show hint ${i + 1} of ${m.hints_total} (-${cost} pts)`
          : `Show hint ${i + 1} of ${m.hints_total} (free)`;
        html += `<button class="btn ghost" type="button" data-hint="${esc(m.slug)}" data-level="${i + 1}">${label}</button> `;
      }
    }
    return html;
  }

  function lessonHtml(m) {
    if (!m.lesson) return '';
    return `<div class="lesson"><h4>What you learned</h4><p>${esc(m.lesson.what)}</p>
      <strong>How websites fix this</strong><ul>${m.lesson.fix.map((f) => `<li>${esc(f)}</li>`).join('')}</ul></div>`;
  }

  function nextHtml(m) {
    if (m.order < missions.length) {
      return `<p style="margin-top:14px"><button class="btn" type="button" data-next="${esc(m.slug)}">Next mission &rarr;</button></p>`;
    }
    return '<div class="msg ok">That was the last mission. Well done, you finished the whole course!</div>';
  }

  function missionHtml(m, currentSlug) {
    const state = m.solved ? 'done' : (m.locked ? 'locked' : (m.slug === currentSlug ? 'active' : ''));
    const open = m.slug === openSlug ? ' open' : '';
    const prev = missions[m.order - 2];
    const badge = m.solved ? '<span class="chip done">&#10003; Done</span>' : (m.locked ? '<span class="chip">&#128274; Locked</span>' : '');
    const note = notes[m.slug] ? `<div class="msg ${notes[m.slug].kind}">${esc(notes[m.slug].text)}</div>` : '';
    const blood = m.first_blood ? `<span class="chip" title="First blood: ${esc(m.first_blood)}">&#129656; ${esc(m.first_blood)}</span>` : '';
    let body;
    if (m.locked) {
      body = `<p class="muted">Finish <strong>${esc(prev ? prev.title : 'the previous mission')}</strong> first to unlock this mission.</p>`;
    } else {
      body = `<p><strong>The story.</strong> ${esc(m.story)}</p>
        <p><strong>Your goal.</strong> ${esc(m.goal)}</p>
        <p class="muted tiny">Difficulty: ${esc(m.difficulty)} &middot; Suggested tool: <strong>${esc(m.tool)}</strong></p>
        ${m.practice ? `<div class="practice">Practice account: <code>${esc(m.practice)}</code></div>` : ''}
        <p><a class="btn" href="${esc(m.start_url)}" target="_blank" rel="noopener">${esc(m.start_label)} &rarr;</a>
           <span class="muted tiny">&nbsp;opens the pretend bank in a new tab</span></p>
        <div>${hintsHtml(m)}</div>
        ${m.solved ? '' : `<form data-flag="${esc(m.slug)}" class="inline" style="margin-top:14px">
            <input type="text" name="flag" placeholder="HARBOR{...}" autocomplete="off" aria-label="Flag for ${esc(m.title)}" required>
            <button class="btn navy" type="submit">Check flag</button></form>`}
        ${note}${lessonHtml(m)}${m.solved ? nextHtml(m) : ''}`;
    }
    return `<div class="mission ${state}${open}" data-slug="${esc(m.slug)}">
      <div class="bubble">${m.solved ? '&#10003;' : m.order}</div>
      <div class="m-head" data-toggle="${esc(m.slug)}"><h3>${esc(m.title)}</h3>
        <span class="chip">${esc(m.category)}</span>
        <span class="chip tool">${esc(m.tool)}</span>
        <span class="chip xp">${m.points} pts</span>${blood}${badge}</div>
      <div class="m-body">${body}</div></div>`;
  }

  function renderMissions() {
    const current = (missions.find((m) => !m.solved && !m.locked) || {}).slug;
    if (openSlug === null) openSlug = current || (missions[missions.length - 1] || {}).slug;
    $('path').innerHTML = missions.map((m) => missionHtml(m, current)).join('');
  }

  function renderBoard(rows) {
    $('board').innerHTML = rows.length ? rows.map((r) => `
      <tr class="${r.player === nick ? 'me' : ''}"><td>${r.rank}</td>
      <td>${esc(r.player)}${r.first_bloods ? ` <span title="${r.first_bloods} first blood(s)">&#129656;</span>` : ''}</td>
      <td>${esc(r.rank_title)}</td><td>${r.solved}</td><td>${r.hints || 0}</td><td>${r.score}</td></tr>`).join('')
      : '<tr><td colspan="6" class="muted">Nobody yet. Be the first!</td></tr>';
  }

  async function load() {
    const q = encodeURIComponent(nick);
    const [c, p, s] = await Promise.all([
      api('GET', `/api/challenges?player=${q}`), api('GET', `/api/players/${q}`), api('GET', '/api/scoreboard')]);
    missions = c.data;
    renderRank(p.data);
    renderMissions();
    renderBoard(s.data);
  }

  $('nick-suggest').addEventListener('click', () => { $('nick-input').value = suggest(); });
  $('nick-save').addEventListener('click', () => {
    const value = $('nick-input').value.trim();
    if (!/^[A-Za-z0-9 _.\-]{1,40}$/.test(value)) {
      $('nick-error').textContent = 'Use 1 to 40 letters, digits, spaces, dashes or underscores.';
      $('nick-error').style.display = '';
      return;
    }
    nick = value;
    localStorage.setItem(NICK_KEY, nick);
    $('nick-error').style.display = 'none';
    showMain();
    load();
  });
  $('nick-change').addEventListener('click', (ev) => { ev.preventDefault(); showName(); });

  $('path').addEventListener('click', async (ev) => {
    const hintBtn = ev.target.closest('[data-hint]');
    if (hintBtn) {
      const slug = hintBtn.dataset.hint;
      const r = await api('POST', `/api/challenges/${slug}/hint`, { player: nick, level: Number(hintBtn.dataset.level) });
      if (!r.ok) {
        notes[slug] = { kind: 'bad', text: r.data.error || 'Could not get that hint.' };
      } else if (r.data.cost) {
        notes[slug] = { kind: 'info', text: `Hint ${r.data.level} unlocked. This mission is now worth ${r.data.points_now} points.` };
        toast(`Hint unlocked: -${r.data.cost} points from this mission.`);
      } else {
        notes[slug] = { kind: 'info', text: `Hint ${r.data.level} unlocked (free).` };
      }
      openSlug = slug;
      await load();
      return;
    }
    const next = ev.target.closest('[data-next]');
    if (next) {
      const done = missions.find((m) => m.slug === next.dataset.next);
      if (done && done.order < missions.length) {
        openSlug = missions[done.order].slug;
        renderMissions();
        const el = document.querySelector('.mission.open');
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
      return;
    }
    const head = ev.target.closest('[data-toggle]');
    if (head) {
      openSlug = openSlug === head.dataset.toggle ? '' : head.dataset.toggle;
      renderMissions();
    }
  });

  $('path').addEventListener('submit', async (ev) => {
    const form = ev.target.closest('form[data-flag]');
    if (!form) return;
    ev.preventDefault();
    const slug = form.dataset.flag;
    const flag = form.elements.flag.value.trim();
    const r = await api('POST', '/api/score/submit', { player: nick, flag });
    if (!r.ok) {
      notes[slug] = { kind: 'bad', text: r.data.error || 'Something went wrong.' };
    } else if (r.data.correct && !r.data.already_solved) {
      notes[slug] = { kind: 'ok', text: r.data.message };
      toast(r.data.message);
      openSlug = r.data.challenge;
    } else {
      notes[slug] = { kind: r.data.locked ? 'info' : 'bad', text: r.data.message };
    }
    await load();
  });

  if (nick) { showMain(); load(); } else { showName(); }
  // Refresh the scoreboard now and then, but never while someone is typing in a box.
  setInterval(() => {
    const typing = document.activeElement && document.activeElement.tagName === 'INPUT';
    if (nick && !document.hidden && !typing) load();
  }, 15000);
})();
