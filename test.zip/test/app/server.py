"""Harbor Credit Union: Analyst Edition.

A harder version of the Harbor lab. The same pretend bank, but every mission is
built for a real tool: ffuf, gobuster, hydra, Burp Suite, jwt_tool and hashcat.

Two halves live in this one app:
  * /bank/...        the pretend bank website. Its weaknesses are deliberate.
  * /, /missions ... Mission Control: story, hints, flag submission and scoring.

Trainee state (password resets, staff login) is kept per browser in a "sandbox",
so players never change each other's lab. Scores and hints are per player name.
"""
from __future__ import annotations

import hashlib
import hmac
import itertools
import os
import re
import secrets
import threading
from datetime import datetime, timedelta, timezone

import jwt
from flask import Flask, Response, abort, g, jsonify, redirect, render_template, request

from missions import MISSIONS, RANKS

app = Flask(__name__)
app.json.sort_keys = False

STARTED_AT = datetime.now(timezone.utc).isoformat()
FLAG_SECRET = os.environ.get('LAB_FLAG_SECRET') or secrets.token_hex(16)
LOCK = threading.Lock()

# Intentionally weak. Mission 4 asks the player to crack it from a wordlist.
JWT_SECRET = 'harbor2026'
FIRST_BLOOD = os.environ.get('FIRST_BLOOD', '').strip().lower() in ('1', 'true', 'yes')


# ---------------------------------------------------------------------------
# Flags
# ---------------------------------------------------------------------------

def flag_for(slug: str) -> str:
    mac = hmac.new(FLAG_SECRET.encode(), slug.encode(), hashlib.sha256).hexdigest()[:8]
    return 'HARBOR{%s-%s}' % (slug.replace('_', '-'), mac)


BY_SLUG = {m['slug']: m for m in MISSIONS}
ORDER = {m['slug']: i for i, m in enumerate(MISSIONS)}
FLAG_TO_SLUG = {flag_for(m['slug']): m['slug'] for m in MISSIONS}


def render_note(text: str) -> str:
    return re.sub(r'\{FLAG:([a-z_]+)\}', lambda m: flag_for(m.group(1)), text)


# ---------------------------------------------------------------------------
# The pretend bank: people, sessions and reset codes
# ---------------------------------------------------------------------------

MEMBERS = {
    'riley': {'password': 'harbor123', 'name': 'Riley Brooks', 'title': 'Member',
              'note': 'Welcome aboard! You have no new messages.'},
    'alex': {'password': 'Anchor!Tide#2026', 'name': 'Alex Rivera', 'title': 'Loan Officer',
             'note': 'Quarterly loan targets are on track.'},
    'jordan': {'password': 'welcome1', 'name': 'Jordan Lee', 'title': 'Teller',
               'note': 'Reminder from IT: please change your temporary password. Ticket ref: {FLAG:who_works_here}'},
    'sam': {'password': secrets.token_urlsafe(12), 'name': 'Sam Patel', 'title': 'Branch Analyst',
            'note': 'Your password was changed today. Internal ref: {FLAG:pet_name}'},
    'taylor': {'password': secrets.token_urlsafe(12), 'name': 'Taylor Moss', 'title': 'Teller',
               'note': 'Your drawer count matched.'},
    'quinn': {'password': secrets.token_urlsafe(12), 'name': 'Quinn Adler', 'title': 'Internal Auditor',
              'note': 'Audit schedule is attached.'},
    'manager': {'password': secrets.token_urlsafe(12), 'name': 'Priya Nair', 'title': 'Branch Manager',
                'note': 'Vault schedule for Friday. Access ref: {FLAG:lucky_number}'},
    'ceo': {'password': secrets.token_urlsafe(12), 'name': 'Dana Whitfield', 'title': 'Chief Executive Officer',
            'note': 'Board packet draft. Confidential ref: {FLAG:remember_me}'},
}

# Four-digit reset codes, fresh on every start. Mission 5 brute-forces this range.
RESET_TOKENS = {name: secrets.randbelow(1000) + 1000 for name in MEMBERS}

# Sessions that already exist when the lab starts. New logins get the next number.
SESSIONS = {10000: 'taylor', 10001: 'quinn', 10002: 'alex', 10003: 'manager', 10004: 'taylor'}
_session_numbers = itertools.count(10005)


def new_session(username: str) -> int:
    with LOCK:
        number = next(_session_numbers)
        SESSIONS[number] = username
        if len(SESSIONS) > 20000:  # keep memory bounded in a long-running lab
            for key in [k for k in SESSIONS if k > 10004][:10000]:
                del SESSIONS[key]
    return number


def issue_remember(username: str) -> str:
    now = datetime.now(timezone.utc)
    return jwt.encode({'sub': username, 'iat': now, 'exp': now + timedelta(days=30)},
                      JWT_SECRET, algorithm='HS256')


def current_login() -> str | None:
    """Who the site thinks you are. Both checks below are deliberately weak (missions 3 and 4)."""
    remember = request.cookies.get('hcu_remember', '')
    if remember:
        try:
            payload = jwt.decode(remember, JWT_SECRET, algorithms=['HS256'])
            sub = payload.get('sub')
            if sub in MEMBERS:
                return sub
        except jwt.InvalidTokenError:
            pass
    session_id = request.cookies.get('hcu_session', '')
    if session_id.isdigit():
        return SESSIONS.get(int(session_id))
    return None


# ---------------------------------------------------------------------------
# Per-browser sandbox (password resets, staff login). Never shared between trainees.
# ---------------------------------------------------------------------------

SANDBOXES: dict[str, dict] = {}


def current_sandbox() -> dict | None:
    return SANDBOXES.get(request.cookies.get('hcu_sb', ''))


def sandbox() -> dict:
    sid = request.cookies.get('hcu_sb', '')
    if sid not in SANDBOXES:
        with LOCK:
            if len(SANDBOXES) > 5000:
                SANDBOXES.clear()
            sid = secrets.token_hex(8)
            SANDBOXES[sid] = {'pw': {}, 'staff': False, 'reset_ok': None}
        g.new_sandbox = sid
    return SANDBOXES[sid]


@app.after_request
def remember_sandbox(response):
    if getattr(g, 'new_sandbox', None):
        response.set_cookie('hcu_sb', g.new_sandbox, httponly=True, samesite='Lax')
    return response


def check_credentials(username: str, password: str) -> str | None:
    """Returns a failure reason, or None when the username and password are valid."""
    member = MEMBERS.get(username)
    if member is None:
        return 'unknown_user'
    box = current_sandbox() or {}
    expected = box.get('pw', {}).get(username, member['password'])
    if not hmac.compare_digest(password.encode(), expected.encode()):
        return 'bad_password'
    return None


def set_login_cookies(response, username: str, remember: bool):
    response.set_cookie('hcu_session', str(new_session(username)), samesite='Lax')
    if remember:
        response.set_cookie('hcu_remember', issue_remember(username),
                            max_age=60 * 60 * 24 * 30, samesite='Lax')
    else:
        response.delete_cookie('hcu_remember')
    return response


# ---------------------------------------------------------------------------
# Scoring: points, hint penalties, optional first blood.
# Missions unlock one after another. Wrong flags never subtract.
# ---------------------------------------------------------------------------

PLAYERS: dict[str, dict] = {}
FIRST_BLOODS: dict[str, str] = {}
BASE_TOTAL = sum(m['points'] for m in MISSIONS)
MAX_SCORE = BASE_TOTAL + (50 * len(MISSIONS) if FIRST_BLOOD else 0)


def norm_player(raw) -> str | None:
    name = str(raw if raw is not None else '').strip()
    return name if re.fullmatch(r'[A-Za-z0-9 _.\-]{1,40}', name) else None


def get_player(name: str) -> dict:
    with LOCK:
        return PLAYERS.setdefault(name, {'solved': {}, 'hints': {}, 'last': None})


def xp_of(rec: dict | None) -> int:
    return sum(rec['solved'].values()) if rec else 0


def rank_of(xp: int) -> tuple[str, str | None, int]:
    """Returns (rank title, next rank title, points still needed for the next rank)."""
    ladder = [(points, name) for points, name in RANKS if points <= MAX_SCORE]
    title, nxt, need = ladder[0][1], None, 0
    for i, (threshold, name) in enumerate(ladder):
        if xp >= threshold:
            title = name
            if i + 1 < len(ladder):
                nxt, need = ladder[i + 1][1], ladder[i + 1][0] - xp
            else:
                nxt, need = None, 0
    return title, nxt, need


def hint_cost(mission: dict, level: int) -> int:
    """Hint 1 is free. Each later hint costs 15% of the base, and a solve keeps at least 70%."""
    return 0 if level <= 1 else mission['points'] * 15 // 100


def points_now(mission: dict, hints_used: int) -> int:
    penalty = sum(hint_cost(mission, level) for level in range(2, hints_used + 1))
    return max(mission['points'] - penalty, mission['points'] * 70 // 100)


def is_locked(index: int, rec: dict | None) -> bool:
    return index > 0 and not (rec and MISSIONS[index - 1]['slug'] in rec['solved'])


def mission_view(index: int, rec: dict | None) -> dict:
    m = MISSIONS[index]
    solved = bool(rec and m['slug'] in rec['solved'])
    used = rec['hints'].get(m['slug'], 0) if rec else 0
    view = {
        'slug': m['slug'], 'title': m['title'], 'category': m['topic'], 'description': m['story'],
        'points': rec['solved'][m['slug']] if solved else points_now(m, used),
        'base_points': m['points'],
        'solves': sum(1 for p in PLAYERS.values() if m['slug'] in p['solved']),
        'hint_cost': hint_cost(m, used + 1) if used < len(m['hints']) else 0,
        'hint_costs': [hint_cost(m, level) for level in range(1, len(m['hints']) + 1)],
        'tool': m['tool'], 'difficulty': m['difficulty'],
        'first_blood': FIRST_BLOODS.get(m['slug']),
        'order': index + 1, 'locked': is_locked(index, rec), 'solved': solved,
        'story': m['story'], 'goal': m['goal'], 'start_url': m['start_url'], 'start_label': m['start_label'],
        'practice': m['practice'], 'hints_total': len(m['hints']), 'hints': m['hints'][:used],
    }
    if solved:
        view['lesson'] = m['lesson']
    return view


@app.get('/health')
def health():
    return jsonify(status='ok', lab='harbor-advanced', instance_started_at=STARTED_AT,
                   first_blood=FIRST_BLOOD, max_score=MAX_SCORE, missions=len(MISSIONS))


@app.get('/api/challenges')
def api_challenges():
    name = norm_player(request.args.get('player'))
    rec = get_player(name) if name else None
    return jsonify([mission_view(i, rec) for i in range(len(MISSIONS))])


@app.get('/api/players/<name>')
def api_player(name):
    player = norm_player(name)
    if not player:
        return jsonify(error='name must be 1-40 characters: letters, digits, space, _ . -'), 400
    rec = PLAYERS.get(player)
    score = xp_of(rec)
    title, nxt, need = rank_of(score)
    hints_used = [s for s, n in (rec['hints'].items() if rec else []) if n]
    return jsonify(
        player=player, score=score, xp=score, max_score=MAX_SCORE,
        rank_title=title, next_rank=nxt, xp_to_next_rank=need,
        solved=[{'challenge': s, 'points': p} for s, p in (rec['solved'].items() if rec else [])],
        hints_used=hints_used, hints_used_count=sum(rec['hints'].get(s, 0) for s in hints_used) if rec else 0,
        first_bloods=[s for s, who in FIRST_BLOODS.items() if who == player],
    )


@app.get('/api/scoreboard')
def api_scoreboard():
    rows = []
    for name, rec in PLAYERS.items():
        score = xp_of(rec)
        rows.append({'player': name, 'score': score, 'solved': len(rec['solved']),
                     'hints': sum(rec['hints'].values()),
                     'first_bloods': sum(1 for who in FIRST_BLOODS.values() if who == name),
                     'rank_title': rank_of(score)[0], 'last_solve': rec['last']})
    rows.sort(key=lambda r: (-r['score'], -r['solved'], r['last_solve'] or '9'))
    return jsonify([{'rank': i + 1, **row} for i, row in enumerate(rows)])


@app.post('/api/challenges/<slug>/hint')
def api_hint(slug):
    mission = BY_SLUG.get(slug)
    if not mission:
        return jsonify(error='unknown mission'), 404
    data = request.get_json(silent=True) or {}
    player = norm_player(data.get('player'))
    if not player:
        return jsonify(error='pick a trainee name first (letters, digits, space, _ . -)'), 400
    rec = get_player(player)
    if is_locked(ORDER[slug], rec):
        return jsonify(error='This mission is still locked. Finish the one before it first.'), 403
    used = rec['hints'].get(slug, 0)
    level = data.get('level')
    try:
        level = used + 1 if level is None else int(level)
    except (TypeError, ValueError):
        return jsonify(error='level must be a number'), 400
    if level < 1 or level > len(mission['hints']):
        return jsonify(error='there are only %d hints for this mission' % len(mission['hints'])), 400
    if level > used + 1:
        return jsonify(error='Open hint %d first.' % (used + 1)), 400
    if slug in rec['solved'] and level > used:
        return jsonify(error='This mission is already solved. Read the lesson on its card.'), 400
    already = level <= used
    rec['hints'][slug] = max(used, level)
    cost = 0 if already else hint_cost(mission, level)
    return jsonify(hint=mission['hints'][level - 1], level=level, levels_total=len(mission['hints']),
                   cost=cost, charged=False, score=xp_of(rec),
                   points_now=points_now(mission, rec['hints'][slug]), base_points=mission['points'])


@app.post('/api/score/submit')
def api_submit():
    data = request.get_json(silent=True) or {}
    player = norm_player(data.get('player'))
    if not player:
        return jsonify(error='pick a trainee name first (letters, digits, space, _ . -)'), 400
    flag = str(data.get('flag') or '').strip()
    rec = get_player(player)
    slug = FLAG_TO_SLUG.get(flag)
    if slug is None:
        return jsonify(correct=False, already_solved=False, points_awarded=0, score=xp_of(rec),
                       message='That is not a Harbor flag. Flags look like HARBOR{...}. Check for typos and extra spaces.')
    index = ORDER[slug]
    if is_locked(index, rec):
        previous = MISSIONS[index - 1]['title']
        return jsonify(correct=False, already_solved=False, locked=True, points_awarded=0, score=xp_of(rec),
                       message='Nice find! But this mission is still locked. Finish "%s" first, then submit it.' % previous)
    mission = BY_SLUG[slug]
    with LOCK:
        if slug in rec['solved']:
            return jsonify(correct=True, already_solved=True, challenge=slug, points_awarded=0,
                           score=xp_of(rec), message='You already completed this mission.')
        award = points_now(mission, rec['hints'].get(slug, 0))
        bonus = 0
        first_blood = False
        if FIRST_BLOOD and slug not in FIRST_BLOODS:
            FIRST_BLOODS[slug] = player
            bonus = 50
            first_blood = True
        rec['solved'][slug] = award + bonus
        rec['last'] = datetime.now(timezone.utc).isoformat()
    total = xp_of(rec)
    title, nxt, need = rank_of(total)
    message = 'Mission complete! +%d points' % (award + bonus)
    if first_blood:
        message += ' First blood: +50 bonus!'
    return jsonify(correct=True, already_solved=False, challenge=slug, points_awarded=award + bonus,
                   base_points=mission['points'], hint_penalty=mission['points'] - award,
                   first_blood=first_blood, bonus=bonus, score=total,
                   rank_title=title, next_rank=nxt, xp_to_next_rank=need, lesson=mission['lesson'],
                   message=message)


# ---------------------------------------------------------------------------
# Mission Control pages
# ---------------------------------------------------------------------------

@app.get('/')
def start_page():
    return render_template('start.html', missions=MISSIONS,
                           ranks=[(p, n) for p, n in RANKS if p <= MAX_SCORE],
                           first_blood=FIRST_BLOOD, max_score=MAX_SCORE, base_total=BASE_TOTAL)


@app.get('/missions')
def missions_page():
    return render_template('missions.html')


@app.get('/help')
def help_page():
    return render_template('help.html')


@app.get('/toolbox')
def toolbox_page():
    return render_template('toolbox.html')


# ---------------------------------------------------------------------------
# The pretend bank
# ---------------------------------------------------------------------------

@app.get('/bank')
def bank_home():
    return render_template('bank_home.html', who=current_login())


@app.get('/bank/team')
def bank_team():
    return render_template('team.html', who=current_login())


@app.route('/bank/login', methods=['GET', 'POST'])
def bank_login():
    if request.method == 'GET':
        return render_template('login.html', who=current_login(), error=None, username='', need=request.args.get('need'))
    username = (request.form.get('username') or '').strip().lower()
    password = request.form.get('password') or ''
    reason = check_credentials(username, password)
    if reason == 'unknown_user':
        return render_template('login.html', who=None, error="We couldn't find that username.",
                               username=username, need=None)
    if reason == 'bad_password':
        return render_template('login.html', who=None, error="That password isn't right for this username.",
                               username=username, need=None)
    return set_login_cookies(redirect('/bank/account'), username, bool(request.form.get('remember')))


@app.post('/api/auth/login')
def api_auth_login():
    """Form-encoded login for hydra and ffuf. Also accepts JSON."""
    data = request.get_json(silent=True) or request.form
    username = str(data.get('username') or '').strip().lower()
    password = str(data.get('password') or '')
    reason = check_credentials(username, password)
    if reason:
        return jsonify(result='failure', reason=reason), 401
    response = jsonify(result='success', username=username)
    return set_login_cookies(response, username, bool(data.get('remember')))


@app.get('/bank/account')
def bank_account():
    username = current_login()
    if not username:
        return redirect('/bank/login?need=1')
    member = MEMBERS[username]
    return render_template('account.html', who=username, member=member, note=render_note(member['note']))


@app.get('/bank/logout')
def bank_logout():
    response = redirect('/bank')
    response.delete_cookie('hcu_session')
    response.delete_cookie('hcu_remember')
    return response


# Mission 1: the staff portal is not linked anywhere. Players have to find it.
@app.get('/bank/back-office')
def bank_staff():
    return render_template('staff.html', who=current_login(), error=None)


@app.post('/bank/back-office')
def bank_staff_login():
    # Mission 1 weakness: the factory login was never changed.
    if request.form.get('username') == 'admin' and request.form.get('password') == 'admin':
        sandbox()['staff'] = True
        return redirect('/bank/back-office/dashboard')
    return render_template('staff.html', who=current_login(), error='Those staff credentials are not correct.')


@app.get('/bank/back-office/dashboard')
def bank_staff_dashboard():
    if not sandbox()['staff']:
        return redirect('/bank/back-office')
    note = 'The portal is still on its factory settings. Setup ref: %s' % flag_for('front_desk')
    return render_template('staff_dashboard.html', who=current_login(), note=note)


# Mission 5: four-digit reset code, no rate limit.
@app.route('/bank/forgot', methods=['GET', 'POST'])
def bank_forgot():
    if request.method == 'GET':
        return render_template('forgot.html', who=current_login(), step='ask', error=None, username='')
    username = (request.form.get('username') or '').strip().lower()
    if username not in MEMBERS:
        return render_template('forgot.html', who=None, step='ask', error='We could not find that username.',
                               username=username)
    return render_template('forgot.html', who=None, step='token', error=None, username=username)


@app.post('/bank/forgot/verify')
def bank_forgot_verify():
    username = (request.form.get('username') or '').strip().lower()
    token = (request.form.get('token') or '').strip()
    if username not in MEMBERS:
        return redirect('/bank/forgot')
    if not token.isdigit() or int(token) != RESET_TOKENS[username]:
        return render_template('forgot.html', who=None, step='token', error='That code is not correct.',
                               username=username)
    sandbox()['reset_ok'] = username
    return render_template('forgot.html', who=None, step='new', error=None, username=username)


@app.post('/bank/forgot/new')
def bank_forgot_new():
    username = (request.form.get('username') or '').strip().lower()
    password = request.form.get('password') or ''
    box = sandbox()
    if box['reset_ok'] != username or username not in MEMBERS:
        return redirect('/bank/forgot')
    if len(password) < 6:
        return render_template('forgot.html', who=None, step='new', error='Choose a password with at least 6 characters.',
                               username=username)
    box['pw'][username] = password
    box['reset_ok'] = None
    return render_template('forgot.html', who=None, step='done', error=None, username=username)


# Decoy pages: all real 200s, none of them the staff portal.
DECOYS = {
    'careers': {'title': 'Careers at Harbor', 'subtitle': 'Join a team that feels like family.',
                'body': 'We are hiring tellers and loan officers. Ask at any branch for an application.'},
    'news': {'title': 'Harbor news', 'subtitle': 'What is happening at the credit union.',
             'body': 'Our new online banking portal is coming soon. Watch this page for updates.'},
    'atm': {'title': 'ATM locator', 'subtitle': 'Cash when you need it.',
            'body': 'Harbor has ATMs at every branch. There is no fee for members.'},
    'rates': {'title': 'Rates and fees', 'subtitle': 'Simple, honest pricing.',
              'body': 'Savings rates are posted at the branch. Loan rates depend on the term and your credit history.'},
}


@app.get('/bank/<page>')
def bank_decoy(page):
    info = DECOYS.get(page)
    if not info:
        abort(404)
    return render_template('decoy.html', who=current_login(), **info)


@app.get('/robots.txt')
def robots():
    return Response(
        'User-agent: *\n'
        'Disallow: /bank/careers\n'
        'Disallow: /bank/news\n'
        'Disallow: /bank/atm\n'
        'Disallow: /bank/rates\n'
        'Disallow: /bank/login\n',
        mimetype='text/plain')
